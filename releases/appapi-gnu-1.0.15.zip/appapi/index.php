<?php
/**
 * 게시판모아 앱 연결 파일: 앱(예전 앱 포함)이 찾는 <사이트>/appapi/index.php → 모듈 <사이트>/plugin/appapi/api.php
 */
$boardmoa_api = dirname(__DIR__) . '/plugin/appapi/api.php';
if (!is_file($boardmoa_api)) {
    header('Content-Type: application/json; charset=utf-8', true, 404);
    echo '{"ok":false,"error":{"code":"unknown_route","message":"BoardMoa module (plugin/appapi) is not installed"}}';
    exit;
}
require $boardmoa_api;
