<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 모듈이 쓰는 표 두 개 (그누보드 표 접두사 + appapi_…). XE1 모듈·XE3·WordPress 플러그인과 같은 동작.
 * - appapi_tokens: 기기별 로그인 토큰 (원문 대신 SHA-256 해시만)
 * - appapi_views: 앱 접속 번호(X-BoardHub-Session)별로 읽은 글 (하루, 해시만) — 웹의 '한 세션에 한 번' 조회수와 같게
 */
class BoardMoa_Store
{
    const ACCESS_TTL = 3600;
    const REFRESH_TTL = 31536000;
    const DB_VERSION = '1';

    public static function tokens()
    {
        return G5_TABLE_PREFIX . 'appapi_tokens';
    }

    public static function views()
    {
        return G5_TABLE_PREFIX . 'appapi_views';
    }

    private static function marker()
    {
        return G5_DATA_PATH . '/cache/appapi-db-' . self::DB_VERSION;
    }

    public static function ensureTables()
    {
        if (is_file(self::marker())) {
            return;
        }
        $tokens = self::tokens();
        $views = self::views();
        sql_query("CREATE TABLE IF NOT EXISTS `$tokens` (
  token_id int(10) unsigned NOT NULL AUTO_INCREMENT,
  mb_id varchar(20) NOT NULL,
  access_hash char(64) NOT NULL,
  access_expires int(10) unsigned NOT NULL,
  refresh_hash char(64) NOT NULL,
  prev_refresh_hash char(64) DEFAULT NULL,
  refresh_expires int(10) unsigned NOT NULL,
  password_sig char(64) NOT NULL,
  device_name varchar(100) NOT NULL DEFAULT '',
  platform varchar(20) NOT NULL DEFAULT '',
  ipaddress varchar(64) NOT NULL DEFAULT '',
  created int(10) unsigned NOT NULL,
  last_used int(10) unsigned NOT NULL,
  PRIMARY KEY (token_id),
  UNIQUE KEY access_hash (access_hash),
  UNIQUE KEY refresh_hash (refresh_hash),
  KEY prev_refresh_hash (prev_refresh_hash),
  KEY mb_id (mb_id)
) DEFAULT CHARSET=utf8", false);
        sql_query("CREATE TABLE IF NOT EXISTS `$views` (
  view_hash char(64) NOT NULL,
  created int(10) unsigned NOT NULL,
  PRIMARY KEY (view_hash),
  KEY created (created)
) DEFAULT CHARSET=utf8", false);
        $ok = sql_fetch("SHOW TABLES LIKE '$tokens'", false);
        if ($ok) {
            @mkdir(dirname(self::marker()), G5_DIR_PERMISSION, true);
            @file_put_contents(self::marker(), date('c'));
        }
    }

    private static function q($value)
    {
        return sql_real_escape_string((string)$value);
    }

    // ---- 토큰

    public static function passwordSig($passwordHash)
    {
        return hash('sha256', 'appapi|' . $passwordHash);
    }

    private static function newToken()
    {
        return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    private static function hash($token)
    {
        return hash('sha256', (string)$token);
    }

    private static function output($access, $refresh)
    {
        return array(
            'access_token' => $access,
            'access_expires_in' => self::ACCESS_TTL,
            'refresh_token' => $refresh,
            'refresh_expires_in' => self::REFRESH_TTL,
        );
    }

    public static function issue($mbId, $passwordHash, $deviceName, $platform, $ip)
    {
        $access = self::newToken();
        $refresh = self::newToken();
        $now = time();
        $table = self::tokens();
        sql_query("INSERT INTO `$table` SET mb_id = '" . self::q($mbId) . "',
            access_hash = '" . self::hash($access) . "', access_expires = " . ($now + self::ACCESS_TTL) . ",
            refresh_hash = '" . self::hash($refresh) . "', refresh_expires = " . ($now + self::REFRESH_TTL) . ",
            password_sig = '" . self::passwordSig($passwordHash) . "',
            device_name = '" . self::q(mb_substr((string)$deviceName, 0, 100)) . "', platform = '" . self::q(mb_substr((string)$platform, 0, 20)) . "',
            ipaddress = '" . self::q($ip) . "', created = $now, last_used = $now");
        if (mt_rand(1, 50) === 1) {
            sql_query("DELETE FROM `$table` WHERE refresh_expires < $now");
        }
        return self::output($access, $refresh);
    }

    public static function findByAccess($access)
    {
        if ((string)$access === '' || !preg_match('/^[A-Za-z0-9_\-]{20,100}$/', (string)$access)) {
            return null;
        }
        $row = sql_fetch("SELECT * FROM `" . self::tokens() . "` WHERE access_hash = '" . self::hash($access) . "'", false);
        return ($row && (int)$row['access_expires'] >= time()) ? $row : null;
    }

    /** 새 접근 토큰이 처음 쓰였으니 직전 갱신 토큰은 더 받지 않는다 */
    public static function touch($row)
    {
        $now = time();
        if ($row['prev_refresh_hash'] !== null || (int)$row['last_used'] < $now - 60) {
            sql_query("UPDATE `" . self::tokens() . "` SET last_used = $now, prev_refresh_hash = NULL WHERE token_id = " . (int)$row['token_id']);
        }
    }

    /** 갱신 토큰으로 새 쌍 (회전). 응답이 유실돼도 새 접근 토큰이 처음 쓰일 때까지 직전 갱신 토큰도 받는다. [행, 토큰] 또는 null */
    public static function rotate($refresh, $ip)
    {
        if ((string)$refresh === '' || !preg_match('/^[A-Za-z0-9_\-]{20,100}$/', (string)$refresh)) {
            return null;
        }
        $hash = self::hash($refresh);
        $table = self::tokens();
        $row = sql_fetch("SELECT * FROM `$table` WHERE refresh_hash = '$hash' OR prev_refresh_hash = '$hash' LIMIT 1", false);
        if (!$row || (int)$row['refresh_expires'] < time()) {
            return null;
        }
        $access = self::newToken();
        $newRefresh = self::newToken();
        $now = time();
        sql_query("UPDATE `$table` SET access_hash = '" . self::hash($access) . "', access_expires = " . ($now + self::ACCESS_TTL) . ",
            refresh_hash = '" . self::hash($newRefresh) . "', prev_refresh_hash = '" . self::q($row['refresh_hash']) . "',
            refresh_expires = " . ($now + self::REFRESH_TTL) . ", ipaddress = '" . self::q($ip) . "', last_used = $now
            WHERE token_id = " . (int)$row['token_id']);
        return array($row, self::output($access, $newRefresh));
    }

    public static function revoke($tokenId)
    {
        sql_query("DELETE FROM `" . self::tokens() . "` WHERE token_id = " . (int)$tokenId);
    }

    public static function revokeMember($mbId)
    {
        sql_query("DELETE FROM `" . self::tokens() . "` WHERE mb_id = '" . self::q($mbId) . "'");
    }

    // ---- 읽은 글 (조회수)

    private static function viewHash($boTable, $wrId)
    {
        $session = isset($_SERVER['HTTP_X_BOARDHUB_SESSION']) ? (string)$_SERVER['HTTP_X_BOARDHUB_SESSION'] : '';
        if (!preg_match('/^[A-Za-z0-9\-]{16,64}$/', $session)) {
            return null;
        }
        return hash('sha256', $session . '|' . $boTable . '|' . (int)$wrId);
    }

    /** 이 앱 접속에서 이미 읽은 글인가 (하루). 접속 번호가 없으면(예전 앱) 늘 처음 */
    public static function viewed($boTable, $wrId)
    {
        $hash = self::viewHash($boTable, $wrId);
        return $hash !== null && (bool)sql_fetch("SELECT view_hash FROM `" . self::views() . "` WHERE view_hash = '$hash' AND created > " . (time() - 86400), false);
    }

    /** 읽었다고 적어 둔다 (웹의 세션 ss_view_… 와 같다) */
    public static function markViewed($boTable, $wrId)
    {
        $hash = self::viewHash($boTable, $wrId);
        if ($hash === null) {
            return;
        }
        $table = self::views();
        $now = time();
        sql_query("REPLACE INTO `$table` SET view_hash = '$hash', created = $now", false);
        if (mt_rand(1, 100) === 1) {
            sql_query("DELETE FROM `$table` WHERE created < " . ($now - 86400), false);
        }
    }
}
