<?php
/**
 * 게시판모아 그누보드 연결 모듈 — 공통 시작 (api.php·admin.php 가 부른다).
 * XE1·Rhymix 모듈(server/appapi)·XE3·WordPress 플러그인과 같은 규약(docs/API.md)으로 응답해서, 앱은 엔진을 구별하지 않는다.
 * 설치: <그누보드>/plugin/appapi/ (+ 예전 앱이 찾는 연결 파일 <그누보드>/appapi/index.php)
 * PHP 7.0 이상 (그누보드 5.4~5.6 이 도는 서버).
 */
if (!defined('BOARDMOA_GNU')) {
    define('BOARDMOA_GNU', true);
    define('BOARDMOA_VERSION', '1.0.26');
    define('BOARDMOA_DIR', __DIR__);

    require_once __DIR__ . '/lib/Error.php';
    require_once __DIR__ . '/lib/Text.php';
    require_once __DIR__ . '/lib/Session.php';
    require_once __DIR__ . '/lib/Store.php';
    require_once __DIR__ . '/lib/Html.php';
    require_once __DIR__ . '/lib/Engine.php';
    require_once __DIR__ . '/lib/Api.php';
    require_once __DIR__ . '/lib/Boards.php';
    require_once __DIR__ . '/lib/Write.php';
    require_once __DIR__ . '/lib/My.php';
    require_once __DIR__ . '/lib/Me.php';
    require_once __DIR__ . '/lib/Updater.php';
}
