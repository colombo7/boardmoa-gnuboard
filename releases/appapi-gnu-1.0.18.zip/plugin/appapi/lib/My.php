<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 내 활동(내 글·댓글·스크랩)·쪽지·글쓴이 이름 메뉴·회원 정보·가입 안내.
 * 그누보드 웹의 회원 메뉴(쪽지·스크랩)와 새글(bbs/new.php?mb_id=)·자기소개(bbs/profile.php)와 같은 기준.
 */
class BoardMoa_My
{
    const PER_PAGE = 20;
    const MAX_PAGE = 50;

    private static function me()
    {
        return BoardMoa_Api::member();
    }

    private static function q($v)
    {
        return sql_real_escape_string((string)$v);
    }

    public static function menu()
    {
        $unread = function_exists('get_memo_not_read') ? (int)get_memo_not_read(self::me()['mb_id']) : 0;
        return array('items' => array(
            array('key' => 'documents', 'title' => BoardMoa_Text::t('내가 쓴 글')),
            array('key' => 'comments', 'title' => BoardMoa_Text::t('내가 쓴 댓글')),
            array('key' => 'scraps', 'title' => BoardMoa_Text::t('스크랩')),
            array('key' => 'messages', 'title' => BoardMoa_Text::t('쪽지'), 'badge' => $unread),
        ));
    }

    /** 목록을 볼 수 있고 전체 검색(새글)에 나오는 게시판 */
    private static function boards()
    {
        $out = array();
        foreach (BoardMoa_Boards::all() as $b) {
            if (BoardMoa_Boards::canList($b)) {
                $out[$b['bo_table']] = $b;
            }
        }
        return $out;
    }

    private static function page()
    {
        return min(self::MAX_PAGE, max(1, BoardMoa_Api::intParam('page', 1)));
    }

    /** 게시판마다 내 글(또는 댓글)을 모아 최신순 쪽 */
    private static function collect($comments)
    {
        global $g5;
        $page = self::page();
        $need = $page * self::PER_PAGE;
        $id = self::q(self::me()['mb_id']);
        $rows = array();
        $total = 0;
        foreach (self::boards() as $b) {
            $table = $g5['write_prefix'] . $b['bo_table'];
            $where = "mb_id = '$id' and wr_is_comment = " . ($comments ? 1 : 0);
            $c = sql_fetch(" select count(*) as cnt from `$table` where $where ", false);
            if (empty($c['cnt'])) {
                continue;
            }
            $total += (int)$c['cnt'];
            $result = sql_query(" select * from `$table` where $where order by wr_datetime desc, wr_id desc limit $need ", false);
            while ($result && ($row = sql_fetch_array($result))) {
                $rows[] = array('time' => BoardMoa_Html::timestamp($row['wr_datetime']), 'b' => $b, 'row' => $row);
            }
        }
        usort($rows, function ($x, $y) {
            return $y['time'] - $x['time'];
        });
        return array(array_slice($rows, ($page - 1) * self::PER_PAGE, self::PER_PAGE), $page, $total);
    }

    public static function documents()
    {
        list($rows, $page, $total) = self::collect(false);
        $documents = array();
        foreach ($rows as $r) {
            $s = BoardMoa_Boards::summary($r['b'], $r['row']);
            $s['mid'] = $r['b']['bo_table'];
            $s['board_title'] = BoardMoa_Boards::title($r['b']);
            $documents[] = $s;
        }
        return array('documents' => $documents, 'page' => $page, 'total_pages' => max(1, min(self::MAX_PAGE, (int)ceil($total / self::PER_PAGE))), 'total_count' => $total);
    }

    public static function comments()
    {
        global $g5;
        list($rows, $page, $total) = self::collect(true);
        $out = array();
        foreach ($rows as $r) {
            $c = $r['row'];
            $parent = sql_fetch(" select wr_subject from `{$g5['write_prefix']}{$r['b']['bo_table']}` where wr_id = '" . (int)$c['wr_parent'] . "' ");
            $out[] = array(
                'comment_srl' => (int)$c['wr_id'],
                'document_srl' => (int)$c['wr_parent'],
                'content' => mb_substr(trim(preg_replace('/\s+/u', ' ', (string)$c['wr_content'])), 0, 200),
                'regdate' => BoardMoa_Html::iso($c['wr_datetime']),
                'is_secret' => BoardMoa_Boards::isSecret($c),
                'document_title' => isset($parent['wr_subject']) ? html_entity_decode((string)$parent['wr_subject'], ENT_QUOTES, 'UTF-8') : '',
                'mid' => $r['b']['bo_table'],
                'board_title' => BoardMoa_Boards::title($r['b']),
            );
        }
        return array('comments' => $out, 'page' => $page, 'total_pages' => max(1, min(self::MAX_PAGE, (int)ceil($total / self::PER_PAGE))), 'total_count' => $total);
    }

    // ---- 스크랩 (bbs/scrap.php)

    public static function scraps()
    {
        global $g5;
        $page = min(10000, max(1, BoardMoa_Api::intParam('page', 1)));
        $id = self::q(self::me()['mb_id']);
        $c = sql_fetch(" select count(*) as cnt from {$g5['scrap_table']} where mb_id = '$id' ");
        $total = (int)$c['cnt'];
        $result = sql_query(" select * from {$g5['scrap_table']} where mb_id = '$id' order by ms_id desc limit " . (($page - 1) * self::PER_PAGE) . ", " . self::PER_PAGE);
        $out = array();
        while ($s = sql_fetch_array($result)) {
            $b = BoardMoa_Boards::get($s['bo_table']);
            $row = $b ? sql_fetch(" select wr_id, wr_subject, wr_name, wr_is_comment from `{$g5['write_prefix']}{$b['bo_table']}` where wr_id = '" . (int)$s['wr_id'] . "' ") : null;
            $exists = $b && !empty($row['wr_id']) && BoardMoa_Boards::canList($b);
            $out[] = array(
                'document_srl' => (int)$s['wr_id'],
                'title' => $exists ? html_entity_decode((string)$row['wr_subject'], ENT_QUOTES, 'UTF-8') : BoardMoa_Text::t('삭제된 글입니다.'),
                'author' => $exists ? (string)$row['wr_name'] : '',
                'scrapped_at' => BoardMoa_Html::iso($s['ms_datetime']),
                'mid' => $b ? $b['bo_table'] : (string)$s['bo_table'],
                'board_title' => $b ? BoardMoa_Boards::title($b) : '',
                'exists' => $exists,
            );
        }
        return array('documents' => $out, 'folders' => array(), 'folder_srl' => null, 'page' => $page,
            'total_pages' => max(1, (int)ceil($total / self::PER_PAGE)), 'total_count' => $total);
    }

    /** 스크랩 빼기 (bbs/scrap_delete.php). 그누보드 글 번호는 게시판마다 따로라 mid 가 오면 그 게시판, 없으면 가장 최근 스크랩 */
    public static function scrapDelete()
    {
        global $g5;
        $id = self::q(self::me()['mb_id']);
        $where = " where mb_id = '$id' and wr_id = '" . BoardMoa_Api::intParam('document_srl') . "' ";
        $mid = (string)BoardMoa_Api::param('mid', '');
        if ($mid !== '') {
            $where .= " and bo_table = '" . self::q(preg_replace('/[^A-Za-z0-9_]/', '', $mid)) . "' ";
        }
        $s = sql_fetch(" select ms_id from {$g5['scrap_table']} $where order by ms_id desc limit 1 ");
        if (empty($s['ms_id'])) {
            throw new BoardMoa_Error(404, 'not_found', '스크랩한 글이 아닙니다.');
        }
        BoardMoa_Engine::input(array('ms_id' => (int)$s['ms_id']), true);
        try {
            BoardMoa_Engine::run(G5_BBS_PATH . '/scrap_delete.php');
        } catch (BoardMoa_Alert $e) {
            throw BoardMoa_Write::alertError($e->getMessage());
        }
        return array('deleted' => true);
    }

    // ---- 쪽지 (bbs/memo.php·memo_view.php·memo_delete.php·memo_form_update.php)

    private static function kind()
    {
        $type = strtoupper((string)BoardMoa_Api::param('message_type', 'R'));
        if ($type === 'T') {
            throw new BoardMoa_Error(403, 'feature_disabled', '이 사이트에서는 쓸 수 없는 기능입니다.');
        }
        return $type === 'S' ? array('send', 'recv', 'S') : array('recv', 'send', 'R');
    }

    /** 그누보드 쪽지는 제목이 없다: 첫 줄을 제목으로 */
    private static function titleOf($memo)
    {
        $first = trim(strtok(str_replace("\r", '', (string)$memo), "\n"));
        return mb_strlen($first) > 40 ? mb_substr($first, 0, 40) . '…' : $first;
    }

    public static function messages()
    {
        global $g5;
        list($kind, $unkind, $type) = self::kind();
        $id = self::q(self::me()['mb_id']);
        $page = min(10000, max(1, BoardMoa_Api::intParam('page', 1)));
        $c = sql_fetch(" select count(*) as cnt from {$g5['memo_table']} where me_{$kind}_mb_id = '$id' and me_type = '$kind' ");
        $total = (int)$c['cnt'];
        $result = sql_query(" select a.*, b.mb_no, b.mb_nick from {$g5['memo_table']} a left join {$g5['member_table']} b on (a.me_{$unkind}_mb_id = b.mb_id)
            where a.me_{$kind}_mb_id = '$id' and a.me_type = '$kind' order by a.me_id desc limit " . (($page - 1) * self::PER_PAGE) . ", " . self::PER_PAGE);
        $out = array();
        while ($m = sql_fetch_array($result)) {
            $out[] = array(
                'message_srl' => (int)$m['me_id'],
                'title' => self::titleOf($m['me_memo']),
                'member_srl' => (int)$m['mb_no'],
                'nick_name' => $m['mb_nick'] !== null ? (string)$m['mb_nick'] : (string)$m['me_' . $unkind . '_mb_id'],
                'regdate' => BoardMoa_Html::iso($m['me_send_datetime']),
                'readed' => strpos((string)$m['me_read_datetime'], '0000') !== 0,
            );
        }
        return array('messages' => $out, 'message_type' => $type, 'unread' => (int)get_memo_not_read(self::me()['mb_id']),
            'page' => $page, 'total_pages' => max(1, (int)ceil($total / self::PER_PAGE)), 'total_count' => $total);
    }

    public static function message()
    {
        global $g5;
        list($kind, $unkind, $type) = self::kind();
        $me = self::me();
        $meId = BoardMoa_Api::intParam('message_srl');
        $m = sql_fetch(" select * from {$g5['memo_table']} where me_id = '$meId' and me_{$kind}_mb_id = '" . self::q($me['mb_id']) . "' ");
        if (empty($m['me_id'])) {
            throw new BoardMoa_Error(404, 'not_found', '없는 쪽지입니다.');
        }
        if ($kind === 'recv') {
            // memo_view.php 와 같게 읽음으로 (보낸 쪽 사본도)
            sql_query(" update {$g5['memo_table']} set me_read_datetime = '" . G5_TIME_YMDHIS . "' where (me_id = '$meId' or me_send_id = '$meId') and me_recv_mb_id = '" . self::q($me['mb_id']) . "' and me_read_datetime = '0000-00-00 00:00:00' ");
            sql_query(" update `{$g5['member_table']}` set mb_memo_cnt = '" . get_memo_not_read($me['mb_id']) . "' where mb_id = '" . self::q($me['mb_id']) . "' ");
        }
        $other = get_member($m['me_' . $unkind . '_mb_id'], 'mb_no, mb_nick');
        return array(
            'message_srl' => (int)$m['me_id'],
            'message_type' => $type,
            'title' => self::titleOf($m['me_memo']),
            'content' => (string)$m['me_memo'],
            'regdate' => BoardMoa_Html::iso($m['me_send_datetime']),
            'member_srl' => isset($other['mb_no']) ? (int)$other['mb_no'] : 0,
            'nick_name' => isset($other['mb_nick']) ? (string)$other['mb_nick'] : (string)$m['me_' . $unkind . '_mb_id'],
            'sent' => $kind === 'send',
        );
    }

    public static function messageDelete()
    {
        global $g5;
        $me = self::me();
        $meId = BoardMoa_Api::intParam('message_srl');
        $m = sql_fetch(" select me_type from {$g5['memo_table']} where me_id = '$meId' and (me_recv_mb_id = '" . self::q($me['mb_id']) . "' or me_send_mb_id = '" . self::q($me['mb_id']) . "') ");
        if (empty($m['me_type'])) {
            throw new BoardMoa_Error(404, 'not_found', '없는 쪽지입니다.');
        }
        $token = uniqid(time());
        set_session('ss_memo_delete_token', $token);
        BoardMoa_Engine::input(array('me_id' => $meId, 'token' => $token, 'kind' => $m['me_type']), true);
        try {
            BoardMoa_Engine::run(G5_BBS_PATH . '/memo_delete.php');
        } catch (BoardMoa_Alert $e) {
            throw BoardMoa_Write::alertError($e->getMessage());
        }
        return array('deleted' => true);
    }

    /** 쪽지 보내기 (memo_form_update.php: 받는 회원의 정보공개·차단, 쪽지 포인트, 캡챠는 엔진이) */
    public static function messageSend()
    {
        global $g5;
        $receiver = sql_fetch(" select mb_id from {$g5['member_table']} where mb_no = '" . BoardMoa_Api::intParam('receiver_srl') . "' ");
        if (empty($receiver['mb_id'])) {
            throw new BoardMoa_Error(404, 'not_found', '없는 회원입니다.');
        }
        $title = trim((string)BoardMoa_Api::param('title', ''));
        $content = trim(str_replace(array("\r\n", "\r"), "\n", (string)BoardMoa_Api::param('content', '')));
        $memo = $title !== '' && strpos($content, $title) !== 0 ? $title . "\n\n" . $content : $content;
        if ($memo === '') {
            throw new BoardMoa_Error(400, 'missing_content', '내용을 입력하세요.');
        }
        // 웹 쪽지 양식처럼 캡챠 (그누보드는 회원도 쪽지에 캡챠를 쓴다)
        $answer = (string)BoardMoa_Api::param('captcha_response', '');
        $widget = BoardMoa_Write::captchaWidget();
        if (!BoardMoa_Write::captchaPass($answer, $widget)) {
            throw new BoardMoa_Error(403, 'captcha_required', $widget ? '자동등록방지 확인이 필요합니다.' : '이 사이트는 쪽지를 보낼 때 자동등록방지 확인이 필요해 웹에서 보내 주세요.', false, array('captcha' => $widget));
        }
        // 이 요청은 사이트 안의 쪽지 양식에서 온 것과 같다 (check_request_origin)
        $_SERVER['HTTP_REFERER'] = G5_BBS_URL . '/memo_form.php';
        BoardMoa_Engine::input(array('me_recv_mb_id' => $receiver['mb_id'], 'me_memo' => mb_substr($memo, 0, 20000)));
        BoardMoa_Engine::$captured = array();
        try {
            BoardMoa_Engine::run(G5_BBS_PATH . '/memo_form_update.php');
        } catch (BoardMoa_Alert $e) {
            if (empty(BoardMoa_Engine::$captured['memo_sent'])) {
                throw BoardMoa_Write::alertError($e->getMessage());
            }
        }
        if (empty(BoardMoa_Engine::$captured['memo_sent'])) {
            throw new BoardMoa_Error(400, 'send_failed', '쪽지를 보내지 못했습니다.');
        }
        return array('sent' => true);
    }

    // ---- 이름 메뉴·회원 정보 (bbs/profile.php 와 같은 공개 기준)

    private static function target()
    {
        global $g5;
        $mb = sql_fetch(" select * from {$g5['member_table']} where mb_no = '" . BoardMoa_Api::intParam('member_srl') . "' ");
        return !empty($mb['mb_id']) ? $mb : null;
    }

    /** 자기소개를 볼 수 있는가: 로그인하고, 나도 정보공개를 했고(최고관리자·본인은 예외), 상대가 정보공개를 했다 */
    private static function canProfile($mb)
    {
        global $is_admin;
        $me = self::me();
        if (!$me || !$mb) {
            return false;
        }
        if ($is_admin === 'super' || $me['mb_id'] === $mb['mb_id']) {
            return true;
        }
        return $me['mb_open'] && $mb['mb_open'] && !$mb['mb_leave_date'] && !$mb['mb_intercept_date'];
    }

    public static function memberMenu()
    {
        $mb = self::target();
        $actions = array();
        if ($mb) {
            $mid = (string)BoardMoa_Api::param('mid', '');
            $b = $mid !== '' ? BoardMoa_Boards::get($mid) : null;
            // 그 게시판에 그 회원의 글이 있을 때만: 웹 이름 메뉴(아이디가 링크에 든다)는 그 회원의 글·댓글에만 붙는다.
            // 번호를 차례로 넣어 글이 없는 회원·관리자의 아이디까지 모으지 못하게
            $wrote = $b && sql_fetch(" select wr_id from `{$GLOBALS['g5']['write_prefix']}{$b['bo_table']}` where mb_id = '" . sql_real_escape_string($mb['mb_id']) . "' limit 1 ", false);
            if ($b && !empty($wrote['wr_id']) && BoardMoa_Boards::canList($b)) {
                // 그누보드 이름 메뉴의 '아이디로 검색' (bbs/board.php?sfl=mb_id,1&stx=…)
                $actions[] = array('type' => 'documents', 'label' => BoardMoa_Text::t('작성글 보기'), 'mid' => $b['bo_table'],
                    'search' => array('search_target' => 'user_id', 'search_keyword' => $mb['mb_id']));
            }
            if (self::canProfile($mb)) {
                $actions[] = array('type' => 'info', 'label' => BoardMoa_Text::t('자기소개'));
            }
            $me = self::me();
            if ($me && $me['mb_id'] !== $mb['mb_id'] && BoardMoa_Write::captchaWidget() && ($mb['mb_open'] || $GLOBALS['is_admin'] === 'super')) {
                $actions[] = array('type' => 'message', 'label' => BoardMoa_Text::t('쪽지 보내기'));
            }
        }
        return array('member_srl' => BoardMoa_Api::intParam('member_srl'), 'actions' => $actions);
    }

    public static function memberInfo()
    {
        global $config;
        $mb = self::target();
        if (!$mb) {
            throw new BoardMoa_Error(404, 'not_found', '회원정보가 존재하지 않습니다.');
        }
        if (!self::canProfile($mb)) {
            throw new BoardMoa_Error(403, 'not_permitted', self::me() && !self::me()['mb_open'] ? '자신의 정보를 공개하지 않으면 다른분의 정보를 조회할 수 없습니다.' : '정보공개를 하지 않았습니다.');
        }
        $fields = array(array('title' => BoardMoa_Text::t('회원권한'), 'value' => (string)(int)$mb['mb_level']));
        if (!empty($config['cf_use_point'])) {
            $fields[] = array('title' => BoardMoa_Text::t('포인트'), 'value' => number_format((int)$mb['mb_point']));
        }
        if ($mb['mb_homepage'] !== '') {
            $fields[] = array('title' => BoardMoa_Text::t('홈페이지'), 'value' => (string)$mb['mb_homepage']);
        }
        $fields[] = array('title' => BoardMoa_Text::t('회원가입일'), 'value' => substr((string)$mb['mb_datetime'], 0, 10));
        $fields[] = array('title' => BoardMoa_Text::t('최종접속일'), 'value' => substr((string)$mb['mb_today_login'], 0, 10));
        $fields[] = array('title' => BoardMoa_Text::t('자기소개'), 'value' => $mb['mb_profile'] !== '' ? (string)$mb['mb_profile'] : BoardMoa_Text::t('소개 내용이 없습니다.'));
        return array(
            'member_srl' => (int)$mb['mb_no'],
            'nick_name' => (string)$mb['mb_nick'],
            'profile_image' => BoardMoa_Api::avatar($mb['mb_id']),
            'regdate' => BoardMoa_Html::iso($mb['mb_datetime']),
            'fields' => $fields,
        );
    }

    public static function webOnly()
    {
        throw new BoardMoa_Error(403, 'not_permitted', BoardMoa_Text::t('회원정보 수정과 탈퇴는 웹사이트에서 해 주세요.') . "\n" . G5_BBS_URL . '/member_confirm.php?url=register_form.php', true);
    }

    /** 가입은 웹에서 (그누보드 가입 양식·약관·본인확인·캡챠는 웹 화면) */
    public static function signupForm()
    {
        return array(
            'enabled' => true,
            'web_only' => true,
            'web_url' => G5_BBS_URL . '/register.php',
            'basic' => array(), 'agreements' => array(), 'password_hint' => '', 'needs_confirm' => false, 'fields' => array(),
        );
    }
}
