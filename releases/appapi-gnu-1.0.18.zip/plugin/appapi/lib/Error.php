<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/** 앱에 돌려줄 오류 (HTTP 상태, 오류 코드, 사용자에게 보일 문장 — 한국어 원문, BoardMoa_Text 가 바꾼다) */
class BoardMoa_Error extends Exception
{
    public $status;
    public $codeName;
    /** 이미 번역됐거나 그누보드가 만든 문구라 그대로 보낸다 */
    public $raw;
    /** error 에 더할 값 */
    public $extra = array();

    public function __construct($status, $code, $message, $raw = false, array $extra = array())
    {
        parent::__construct((string)$message);
        $this->status = (int)$status;
        $this->codeName = (string)$code;
        $this->raw = (bool)$raw;
        $this->extra = $extra;
    }
}
