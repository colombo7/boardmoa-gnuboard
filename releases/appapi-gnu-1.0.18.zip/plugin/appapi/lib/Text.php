<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 모듈 문구 언어 (한국어 원문 + 앱과 같은 11개 언어). 한국어 원문을 열쇠로 BoardMoa_Text::t('…') 에 넣고, 값 자리는 {0}, {1} …
 * 언어별 문구는 lang/text.<코드>.php (열쇠는 text.en.php 와 같다). 앱에 보내는 문구는 X-App-Lang, 없으면(예전 앱) 한국어(그누보드는 한국어 엔진).
 * 관리 화면은 한국어. 문구 하나가 없으면 그 언어 → 기본 언어 → 영어 → 한국어 원문.
 * 그누보드가 만든 문구(alert)와 사이트 내용은 바꾸지 않는다.
 */
class BoardMoa_Text
{
    const LANGUAGES = array('ko', 'en', 'ja', 'es', 'pt-BR', 'de', 'fr', 'it', 'vi', 'id', 'zh-Hant', 'zh-Hans');

    private static $code = null;
    private static $tables = array();

    public static function code()
    {
        if (self::$code === null) {
            $requested = trim(isset($_SERVER['HTTP_X_APP_LANG']) ? (string)$_SERVER['HTTP_X_APP_LANG'] : '');
            self::$code = (defined('BOARDMOA_DOING_API') && $requested !== '') ? self::resolve($requested) : 'ko';
        }
        return self::$code;
    }

    /** 언어 표시(앱 코드, ko_KR·pt_BR·zh_TW 꼴 등) → 문구 언어. 없는 언어는 영어 */
    public static function resolve($tag)
    {
        $tag = strtolower(str_replace('_', '-', trim((string)$tag)));
        foreach (self::LANGUAGES as $code) {
            if (strtolower($code) === $tag) {
                return $code;
            }
        }
        $parts = explode('-', $tag);
        $base = $parts[0];
        if ($base === 'pt') {
            return 'pt-BR';
        }
        if ($base === 'jp') {
            return 'ja';
        }
        if ($base === 'in') {
            return 'id';
        }
        if ($base === 'zh') {
            $rest = array_slice($parts, 1);
            $traditional = in_array('hant', $rest, true) || (!in_array('hans', $rest, true) && array_intersect(array('tw', 'hk', 'mo'), $rest));
            return $traditional ? 'zh-Hant' : 'zh-Hans';
        }
        return in_array($base, self::LANGUAGES, true) ? $base : 'en';
    }

    private static function table($code)
    {
        if (!isset(self::$tables[$code])) {
            $file = BOARDMOA_DIR . '/lang/text.' . $code . '.php';
            self::$tables[$code] = preg_match('/^[A-Za-z-]+$/', $code) && is_file($file) ? (array)include $file : array();
        }
        return self::$tables[$code];
    }

    public static function t($ko)
    {
        $args = array_slice(func_get_args(), 1);
        $text = (string)$ko;
        $code = self::code();
        if ($code !== 'ko') {
            $parts = explode('-', $code);
            foreach (array_unique(array($code, $parts[0], 'en')) as $c) {
                $table = self::table($c);
                if (isset($table[$text])) {
                    $text = $table[$text];
                    break;
                }
            }
        }
        foreach ($args as $i => $value) {
            $text = str_replace('{' . $i . '}', (string)$value, $text);
        }
        return $text;
    }
}
