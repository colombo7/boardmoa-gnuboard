<?php
/**
 * 관리 화면: 관리자 → 환경설정 → 게시판모아 앱 (최고관리자만). 버전·업데이트·연결 상태·개발자에게 알리기.
 * 그누보드 관리자 화면(adm/admin.head.php)에 넣어 그린다.
 */
require __DIR__ . '/boot.php';

$boardmoa_root = dirname(dirname(__DIR__));
chdir($boardmoa_root . '/' . 'adm');
include_once './_common.php';

if ($is_admin !== 'super') {
    alert('최고관리자만 접근 가능합니다.', G5_URL);
}

$t = function ($ko) {
    return htmlspecialchars(call_user_func_array(array('BoardMoa_Text', 't'), func_get_args()), ENT_QUOTES, 'UTF-8');
};
$self = G5_PLUGIN_URL . '/appapi/admin.php';

// 보내기 단추 (세션 토큰으로 다른 사이트에서 보낸 요청을 막는다)
$result = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sent = isset($_POST['boardmoa_token']) ? (string)$_POST['boardmoa_token'] : '';
    if ($sent === '' || !hash_equals((string)get_session('ss_boardmoa_admin_token'), $sent)) {
        alert('올바른 방법으로 이용해 주십시오.', $self);
    }
    $action = isset($_POST['action']) ? (string)$_POST['action'] : '';
    if ($action === 'update') {
        BoardMoa_Store::ensureTables();
        $result = BoardMoa_Updater::update();
        if (!empty($result['ok'])) {
            BoardMoa_Updater::report();
        }
    } elseif ($action === 'share') {
        BoardMoa_Updater::saveSettings(array('share_site' => (isset($_POST['share_site']) && $_POST['share_site'] === 'Y') ? 'Y' : 'N'));
        goto_url($self);
    }
}
$token = bin2hex(random_bytes(16));
set_session('ss_boardmoa_admin_token', $token);
BoardMoa_Store::ensureTables();

$check = isset($_GET['check']) ? BoardMoa_Updater::check() : null;
$apiUrl = G5_PLUGIN_URL . '/appapi/api.php?r=site';
$extend = is_file(G5_EXTEND_PATH . '/appapi.extend.php');

$sub_menu = '100950';
$g5['title'] = BoardMoa_Text::t('게시판모아 앱 연동');
include_once G5_ADMIN_PATH . '/admin.head.php';
?>
<section class="boardmoa-admin" style="max-width:860px">
    <p><?php echo $t('게시판모아(BoardMoa) 앱에서 이 사이트의 게시판을 보고 쓸 수 있게 하는 플러그인입니다. 글을 읽고 쓸 수 있는 사람은 그누보드의 게시판 권한(레벨·그룹 접근·비밀글) 설정과 같습니다.'); ?></p>

    <?php if ($result) { ?>
    <div class="local_desc01 local_desc" style="border-color:<?php echo !empty($result['ok']) ? '#3a3' : '#c33'; ?>">
        <p><?php echo htmlspecialchars($result['message'], ENT_QUOTES, 'UTF-8'); ?>
        <?php if (!empty($result['backup'])) { ?><br><small><?php echo $t('이전 파일 백업: {0}', $result['backup']); ?></small><?php } ?></p>
    </div>
    <?php } ?>

    <h2 class="h2_frm"><?php echo $t('버전과 업데이트'); ?></h2>
    <div class="tbl_frm01 tbl_wrap">
        <table>
            <tbody>
            <tr>
                <th scope="row"><?php echo $t('설치된 버전'); ?></th>
                <td><?php echo htmlspecialchars(BoardMoa_Updater::currentVersion(), ENT_QUOTES, 'UTF-8'); ?></td>
            </tr>
            <tr>
                <th scope="row"><?php echo $t('업데이트'); ?></th>
                <td>
                <?php if ($check) { ?>
                    <?php if ($check['error']) { ?>
                        <p><?php echo htmlspecialchars($check['error'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php } elseif ($check['has_update']) { ?>
                        <p><strong><?php echo $t('새 버전: {0}', $check['latest']); ?></strong> (<?php echo htmlspecialchars($check['date'], ENT_QUOTES, 'UTF-8'); ?>)</p>
                        <?php if ($check['notes']) { ?><p style="white-space:pre-line"><?php echo htmlspecialchars($check['notes'], ENT_QUOTES, 'UTF-8'); ?></p><?php } ?>
                        <?php if (!$check['zip_available'] || !$check['writable']) { ?>
                            <p><?php echo $t('이 서버에서는 자동 업데이트를 할 수 없습니다. 공개 저장소에서 새 버전을 내려받아 plugin/appapi 폴더를 직접 바꿔 주세요.'); ?></p>
                        <?php } else { ?>
                            <form method="post" action="<?php echo $self; ?>">
                                <input type="hidden" name="boardmoa_token" value="<?php echo $token; ?>">
                                <input type="hidden" name="action" value="update">
                                <button type="submit" class="btn btn_01"><?php echo $t('{0} 버전으로 업데이트', $check['latest']); ?></button>
                                <span class="frm_info"><?php echo $t('내려받은 파일의 전자서명을 확인하고, 지금 파일을 백업한 다음 새 파일로 바꿉니다.'); ?></span>
                            </form>
                        <?php } ?>
                    <?php } elseif ($check['is_newer']) { ?>
                        <p><?php echo $t('공개된 최신 버전({0})보다 새 버전이 설치되어 있습니다.', $check['latest']); ?></p>
                    <?php } else { ?>
                        <p><?php echo $t('최신 버전입니다.'); ?></p>
                    <?php } ?>
                <?php } else { ?>
                    <a class="btn btn_02" href="<?php echo $self; ?>?check=1"><?php echo $t('업데이트 확인'); ?></a>
                <?php } ?>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <h2 class="h2_frm"><?php echo $t('연결 상태'); ?></h2>
    <div class="tbl_frm01 tbl_wrap">
        <table>
            <tbody>
            <tr>
                <th scope="row"><?php echo $t('앱 연결 주소'); ?></th>
                <td><a href="<?php echo $apiUrl; ?>" target="_blank"><?php echo htmlspecialchars($apiUrl, ENT_QUOTES, 'UTF-8'); ?></a></td>
            </tr>
            <tr>
                <th scope="row"><?php echo $t('관리자 메뉴 (extend/appapi.extend.php)'); ?></th>
                <td><?php echo $extend ? $t('있음') : $t('없음 (이 화면 주소로 직접 들어오면 됩니다)'); ?></td>
            </tr>
            <tr>
                <th scope="row"><?php echo $t('자동 업데이트'); ?></th>
                <td><?php echo BoardMoa_Updater::writable() ? $t('가능') : $t('플러그인 폴더(plugin/appapi)에 웹 서버의 쓰기 권한이 없어 자동 업데이트를 할 수 없습니다.'); ?></td>
            </tr>
            </tbody>
        </table>
    </div>

    <h2 class="h2_frm"><?php echo $t('설치 현황 — 개발자에게 알리기'); ?></h2>
    <form method="post" action="<?php echo $self; ?>">
        <input type="hidden" name="boardmoa_token" value="<?php echo $token; ?>">
        <input type="hidden" name="action" value="share">
        <input type="hidden" name="share_site" value="N">
        <label><input type="checkbox" name="share_site" value="Y" <?php echo BoardMoa_Updater::shareSite() ? 'checked' : ''; ?> onchange="this.form.submit()"> <?php echo $t('업데이트를 확인할 때 이 사이트 정보를 개발자에게 보내기'); ?></label>
        <p class="frm_info"><?php echo $t('선택해 두면 [업데이트 확인]을 누를 때 사이트 주소, 사이트 이름, 엔진 종류와 버전, 플러그인 버전이 게시판모아 개발자(EasyAppLabs)에게 전송됩니다. 회원 정보와 글 내용은 전송되지 않으며, 전송된 정보는 공개하지 않습니다. 이 정보는 어떤 엔진과 버전에서 플러그인이 쓰이는지 파악해 호환성을 점검하고, 새 기능과 업데이트를 준비하는 데 사용합니다.'); ?></p>
    </form>

    <p class="frm_info" style="margin-top:20px"><?php echo $t('앱의 메뉴는 사이트 메뉴(환경설정 → 메뉴설정, 모바일 메뉴)와 같게 구성됩니다. 목록을 볼 권한이 없는 게시판은 앱 어디에도 표시되지 않습니다.'); ?><br>
    <?php echo $t('내려받기·설치 안내:'); ?> <a href="https://github.com/colombo7/boardmoa-gnuboard" target="_blank">github.com/colombo7/boardmoa-gnuboard</a></p>
</section>
<?php
include_once G5_ADMIN_PATH . '/admin.tail.php';
