<?php
if (!defined('BOARDMOA_GNU')) {
    exit;
}

/**
 * 내 정보 수정 (1.0.20~): me.form · me.update · me.password · me.image.
 * 저장은 웹의 회원정보 수정 처리 파일(bbs/register_form_update.php, w=u)을 그대로 실행한다(BoardMoa_Engine).
 * 그래서 닉네임 금지어·중복·변경 기간, 이메일 금지 도메인·중복, 휴대폰 형식, 본인확인 초기화, 훅·플러그인이 웹과 같다.
 * 처리 파일은 양식에 없는 항목을 빈 값으로 저장하므로 지금 값을 모두 채운 뒤 앱이 보낸 항목만 덮어쓴다.
 * 보이는 항목·필수·읽기 전용은 웹 회원정보 수정 화면(bbs/register_form.php + 기본 회원 스킨)과 같은 설정으로 정한다.
 * 회원 탈퇴는 웹에서 (BoardMoa_My::webOnly).
 */
class BoardMoa_Me
{
    // ---- 화면

    public static function form()
    {
        global $config;
        $mb = self::member();
        return array(
            'nick_name' => (string)$mb['mb_nick'],
            'email_address' => $mb['mb_email'] !== '' ? (string)$mb['mb_email'] : null,
            'profile_image' => BoardMoa_Api::avatar($mb['mb_id']),
            'can_change_nickname' => self::canChangeNick($mb),
            'can_change_email' => self::canChangeEmail(),
            'profile_image_enabled' => self::imageEnabled($mb),
            'profile_image_max_width' => (int)$config['cf_member_img_width'],
            'profile_image_max_height' => (int)$config['cf_member_img_height'],
            'fields' => self::fields($mb),
            // 앱에서 보이지도 고치지도 못하는 항목 안내와 웹 회원정보 수정 주소 (1.0.20~, 새 필드)
            'web_notice' => self::webNotice($mb),
            'web_url' => self::webUrl(),
        );
    }

    /** 웹 회원정보 수정 주소 (비밀번호 확인 → register_form.php) */
    public static function webUrl()
    {
        return G5_BBS_URL . '/member_confirm.php?url=register_form.php';
    }

    /** 닉네임: 웹처럼 마지막으로 바꾼 날에서 cf_nick_modify 일이 지나야 (register_form.php 의 $req_nick) */
    private static function canChangeNick($mb)
    {
        global $config;
        return !isset($mb['mb_nick_date']) || $mb['mb_nick_date'] <= date('Y-m-d', G5_SERVER_TIME - ((int)$config['cf_nick_modify'] * 86400));
    }

    /** 메일 인증을 쓰는 사이트는 이메일을 바꾸면 다시 인증하고 로그아웃된다(웹): 앱에서는 바꾸지 않는다 */
    private static function canChangeEmail()
    {
        global $config;
        return empty($config['cf_use_email_certify']);
    }

    /** 정보공개: 바꾼 날에서 cf_open_modify 일이 지나야 (기본 스킨과 같다) */
    private static function canChangeOpen($mb)
    {
        global $config;
        return empty($mb['mb_open_date']) || $mb['mb_open_date'] <= date('Y-m-d', G5_SERVER_TIME - ((int)$config['cf_open_modify'] * 86400));
    }

    /** 회원 사진(회원이미지): 기본 스킨이 보이는 조건 (레벨이 회원아이콘 레벨 이상, 크기 설정이 있음) */
    private static function imageEnabled($mb)
    {
        global $config;
        return (int)$mb['mb_level'] >= (int)$config['cf_icon_level'] && $config['cf_member_img_size'] && $config['cf_member_img_width'] && $config['cf_member_img_height'];
    }

    /** 휴대폰번호 칸이 보이는가·필수인가·읽기 전용인가 (register_form.php 의 $hp_required·$hp_readonly) */
    private static function hpState($mb)
    {
        global $config;
        $certHp = !empty($config['cf_cert_hp']) || !empty($config['cf_cert_simple']);
        $show = !empty($config['cf_use_hp']) || (!empty($config['cf_cert_use']) && $certHp);
        $locked = !empty($config['cf_cert_use']) && !empty($config['cf_cert_req']) && $certHp && $mb['mb_certify'] !== 'ipin';
        $required = !empty($config['cf_req_hp']) || $locked;
        return array($show, $required, $locked);
    }

    /** 앱에서 고칠 수 있는 칸: 이름 => [필수, 형식]. 웹 화면에 보이고 읽기 전용이 아닌 것 */
    private static function editable($mb)
    {
        global $config;
        $out = array();
        if (!empty($config['cf_use_homepage'])) {
            $out['mb_homepage'] = array(!empty($config['cf_req_homepage']), 'url');
        }
        if (!empty($config['cf_use_tel'])) {
            $out['mb_tel'] = array(!empty($config['cf_req_tel']), 'tel');
        }
        list($hpShow, $hpRequired, $hpLocked) = self::hpState($mb);
        if ($hpShow && !$hpLocked) {
            $out['mb_hp'] = array($hpRequired, 'tel');
        }
        if (!empty($config['cf_use_addr'])) {
            $out['mb_addr'] = array(!empty($config['cf_req_addr']), 'kr_zip');
        }
        if (!empty($config['cf_use_signature'])) {
            $out['mb_signature'] = array(!empty($config['cf_req_signature']), 'textarea');
        }
        if (!empty($config['cf_use_profile'])) {
            $out['mb_profile'] = array(!empty($config['cf_req_profile']), 'textarea');
        }
        if (self::canChangeOpen($mb)) {
            $out['mb_open'] = array(false, 'checkbox');
        }
        return $out;
    }

    private static function field($name, $title, $type, $required, $value, $editable, array $options = array(), array $parts = array())
    {
        return array('name' => $name, 'title' => $title, 'type' => $type, 'required' => (bool)$required, 'value' => (string)$value,
            'options' => $options, 'parts' => $parts, 'editable' => (bool)$editable);
    }

    private static function openOption()
    {
        return BoardMoa_Text::t('다른 분들이 내 정보를 볼 수 있게 합니다');
    }

    /** 웹 회원정보 수정 화면의 항목 차례대로. 읽기 전용(이름·본인확인한 휴대폰·바꿀 수 없는 기간의 정보공개·수신 동의)은 editable false 로 보여 주기만 */
    private static function fields($mb)
    {
        global $config;
        $edit = self::editable($mb);
        $out = array();
        if (!empty($config['cf_cert_use'])) {
            $out[] = self::field('mb_certify', BoardMoa_Text::t('본인확인'), 'text', false,
                $mb['mb_certify'] !== '' ? BoardMoa_Text::t('본인확인 완료') : BoardMoa_Text::t('본인확인 전'), false);
        }
        // 이름: 웹 회원정보 수정에서 늘 읽기 전용 (본인확인으로만 바뀐다)
        $out[] = self::field('mb_name', BoardMoa_Text::t('이름'), 'text', false, $mb['mb_name'], false);
        if (isset($edit['mb_homepage'])) {
            $out[] = self::field('mb_homepage', BoardMoa_Text::t('홈페이지'), 'url', $edit['mb_homepage'][0], $mb['mb_homepage'], true);
        }
        if (isset($edit['mb_tel'])) {
            $out[] = self::field('mb_tel', BoardMoa_Text::t('전화번호'), 'tel', $edit['mb_tel'][0], $mb['mb_tel'], true);
        }
        list($hpShow, $hpRequired, $hpLocked) = self::hpState($mb);
        if ($hpShow) {
            $out[] = self::field('mb_hp', BoardMoa_Text::t('휴대폰번호'), 'tel', $hpRequired, $mb['mb_hp'], !$hpLocked);
        }
        if (isset($edit['mb_addr'])) {
            $value = implode("\n", array($mb['mb_zip1'] . $mb['mb_zip2'], $mb['mb_addr1'], $mb['mb_addr2'], $mb['mb_addr3']));
            // 칸 이름은 앱이 우편번호 검색 결과를 넣을 자리를 찾는 한국어 이름 그대로 (앱이 번역해 보인다)
            $out[] = self::field('mb_addr', BoardMoa_Text::t('주소'), 'kr_zip', $edit['mb_addr'][0], $value, true, array(), array('우편번호', '주소', '상세 주소', '참고 항목'));
        }
        if (isset($edit['mb_signature'])) {
            $out[] = self::field('mb_signature', BoardMoa_Text::t('서명'), 'textarea', $edit['mb_signature'][0], $mb['mb_signature'], true);
        }
        if (isset($edit['mb_profile'])) {
            $out[] = self::field('mb_profile', BoardMoa_Text::t('자기소개'), 'textarea', $edit['mb_profile'][0], $mb['mb_profile'], true);
        }
        if (isset($edit['mb_open'])) {
            $out[] = self::field('mb_open', BoardMoa_Text::t('정보공개'), 'checkbox', false, $mb['mb_open'] ? self::openOption() : '', true, array(self::openOption()));
        } else {
            $out[] = self::field('mb_open', BoardMoa_Text::t('정보공개'), 'text', false, $mb['mb_open'] ? BoardMoa_Text::t('공개') : BoardMoa_Text::t('비공개'), false);
        }
        // 수신 동의 (설정 '광고성 정보 수신 동의 사용'): 웹은 동의 전문(자세히보기)과 함께 고친다. 앱은 보여 주기만
        if (!empty($config['cf_use_promotion'])) {
            $consents = array('mb_marketing_agree' => '마케팅 목적의 개인정보 수집 및 이용', 'mb_mailling' => '광고성 이메일 수신');
            if (!empty($config['cf_use_hp']) || !empty($config['cf_req_hp'])) {
                $consents['mb_sms'] = '광고성 SMS/카카오톡 수신';
            }
            if (!empty($config['cf_sms_use']) && $config['cf_sms_use'] === 'icode') {
                $consents['mb_thirdparty_agree'] = '개인정보 제3자 제공';
            }
            foreach ($consents as $name => $title) {
                $on = isset($mb[$name]) && (int)$mb[$name] === 1;
                $out[] = self::field($name, BoardMoa_Text::t($title), 'text', false, $on ? BoardMoa_Text::t('동의') : BoardMoa_Text::t('동의 안 함'), false);
            }
        }
        return $out;
    }

    /** 앱에서 보이지도 못하는 웹 수정 화면 항목 (본인확인 하기, 회원아이콘, 소셜 로그인 연결). 잠긴 칸(fields 의 editable false)은 넣지 않는다. 없으면 null */
    private static function webNotice($mb)
    {
        global $config;
        $items = array();
        if (!empty($config['cf_cert_use']) && (!empty($config['cf_cert_hp']) || !empty($config['cf_cert_simple']) || !empty($config['cf_cert_ipin']))) {
            $items[] = BoardMoa_Text::t('본인확인');
        }
        if (!empty($config['cf_use_member_icon']) && (int)$mb['mb_level'] >= (int)$config['cf_icon_level']) {
            $items[] = BoardMoa_Text::t('회원아이콘');
        }
        if (!empty($config['cf_social_login_use']) && function_exists('social_member_provider_manage')) {
            $items[] = BoardMoa_Text::t('소셜 로그인 연결');
        }
        return $items ? BoardMoa_Text::t('다음 항목은 웹사이트의 회원정보 수정에서 바꿀 수 있습니다: {0}', implode(', ', $items)) : null;
    }

    // ---- 저장

    /** POST me.update {current_password, nick_name?, email_address?, fields?} → member */
    public static function update()
    {
        $mb = self::member();
        self::checkPassword($mb, (string)BoardMoa_Api::param('current_password', ''));
        $values = self::current($mb);
        $edit = self::editable($mb);
        $titles = array();
        foreach (self::fields($mb) as $f) {
            $titles[$f['name']] = $f['title'];
        }

        $nick = trim((string)BoardMoa_Api::param('nick_name', ''));
        if ($nick !== '' && $nick !== (string)$mb['mb_nick'] && self::canChangeNick($mb)) {
            // 웹 화면이 보내기 전에 확인하는 것(ajax.mb_nick.php) 중 처리 파일이 다시 보지 않는 글자 수
            include_once G5_LIB_PATH . '/register.lib.php';
            if ($msg = count_mb_nick($nick)) {
                throw new BoardMoa_Error(400, 'update_failed', $msg, true);
            }
            $values['mb_nick'] = $nick;
        }
        $email = trim((string)BoardMoa_Api::param('email_address', ''));
        if ($email !== '' && self::canChangeEmail()) {
            $values['mb_email'] = $email;
        }

        $sent = BoardMoa_Api::param('fields');
        if (is_string($sent) && $sent !== '') {
            $sent = json_decode($sent, true);
        }
        $sent = is_array($sent) ? $sent : array();
        foreach ($sent as $name => $value) {
            $name = (string)$name;
            if (!isset($edit[$name]) || is_array($value)) {
                continue; // 보이지 않거나 읽기 전용인 항목은 무시 (웹 화면에도 없거나 잠긴 칸)
            }
            $value = trim((string)$value);
            if ($name === 'mb_addr') {
                $parts = array_pad(explode("\n", str_replace("\r", '', $value)), 4, '');
                $parts = array_map('trim', $parts);
                if ($parts[1] !== (string)$mb['mb_addr1']) {
                    // 앱의 주소 찾기는 도로명 주소를 넣는다 (웹 우편번호 찾기의 R)
                    $values['mb_addr_jibeon'] = $parts[1] !== '' ? 'R' : '';
                }
                $values['mb_zip'] = preg_replace('/[^0-9]/', '', $parts[0]);
                $values['mb_addr1'] = $parts[1];
                $values['mb_addr2'] = $parts[2];
                $values['mb_addr3'] = $parts[3];
            } elseif ($name === 'mb_open') {
                $values['mb_open'] = $value !== '' ? '1' : '0';
            } else {
                $values[$name] = $value;
            }
        }
        // 웹 양식의 필수 칸(required): 처리 파일은 다시 보지 않는다
        foreach ($edit as $name => $info) {
            if (!$info[0]) {
                continue;
            }
            $empty = $name === 'mb_addr' ? ($values['mb_zip'] === '' || trim($values['mb_addr1']) === '') : trim((string)$values[$name]) === '';
            if ($empty) {
                throw new BoardMoa_Error(400, 'update_failed', BoardMoa_Text::t('{0} 항목을 입력해 주세요.', isset($titles[$name]) ? $titles[$name] : $name), true);
            }
        }
        self::save($mb, $values);
        return BoardMoa_Api::profile(get_member($mb['mb_id']));
    }

    /** POST me.password {current_password, new_password} → {tokens}. 이 회원의 다른 앱 로그인은 끊고 이 기기에 새 토큰 */
    public static function password()
    {
        $mb = self::member();
        self::checkPassword($mb, (string)BoardMoa_Api::param('current_password', ''));
        $new = trim((string)BoardMoa_Api::param('new_password', ''));
        // 웹 양식과 같은 길이 (3글자 이상, 입력 칸 최대 20글자). 처리 파일은 trim 한 값을 저장한다
        if (mb_strlen($new) < 3 || mb_strlen($new) > 20) {
            throw new BoardMoa_Error(400, 'invalid_password', '비밀번호를 3~20글자로 입력해 주세요.');
        }
        $values = self::current($mb);
        $values['mb_password'] = $new;
        $values['mb_password_re'] = $new;
        self::save($mb, $values);
        $after = get_member($mb['mb_id']);
        if (empty($after['mb_id']) || !check_password(BoardMoa_Engine::escape($new), $after['mb_password'])) {
            throw new BoardMoa_Error(400, 'update_failed', '처리하지 못했습니다.');
        }
        BoardMoa_Store::revokeMember($mb['mb_id']);
        $token = BoardMoa_Api::$token ?: array();
        $tokens = BoardMoa_Store::issue($mb['mb_id'], $after['mb_password'], isset($token['device_name']) ? $token['device_name'] : '',
            isset($token['platform']) ? $token['platform'] : '', BoardMoa_Api::ip());
        return array('tokens' => $tokens);
    }

    /** POST me.image multipart image → member · {delete: 1} 이면 지운다. 웹 회원정보 수정의 '회원이미지'와 같은 처리 */
    public static function image()
    {
        global $config;
        $mb = self::member();
        if (!self::imageEnabled($mb)) {
            throw new BoardMoa_Error(403, 'not_permitted', '사이트에서 회원 사진을 쓰지 않습니다.');
        }
        $path = G5_DATA_PATH . '/member_image/' . substr($mb['mb_id'], 0, 2) . '/' . get_mb_icon_name($mb['mb_id']) . '.gif';
        $before = is_file($path) ? md5_file($path) : '';
        $values = self::current($mb);
        if (BoardMoa_Api::boolParam('delete')) {
            $values['del_mb_img'] = '1';
            $run = self::save($mb, $values);
        } else {
            $file = isset($_FILES['image']) ? $_FILES['image'] : null;
            if (!$file || !is_uploaded_file($file['tmp_name'])) {
                throw new BoardMoa_Error(400, 'upload_failed', '사진을 올리지 못했습니다.');
            }
            self::shrink($file['tmp_name'], (int)$config['cf_member_img_width'], (int)$config['cf_member_img_height'], (int)$config['cf_member_img_size']);
            $name = preg_match('/\.(gif|jpe?g|png)$/i', (string)$file['name']) ? (string)$file['name'] : 'profile.jpg';
            $_FILES['mb_img'] = array('name' => $name, 'type' => $file['type'], 'tmp_name' => $file['tmp_name'], 'error' => $file['error'], 'size' => filesize($file['tmp_name']));
            $run = self::save($mb, $values);
            clearstatcache();
            $after = is_file($path) ? md5_file($path) : '';
            if ($after === '' || $after === $before) {
                // 처리 파일은 크기·형식이 맞지 않으면 alert() 대신 <script>alert(…)</script> 를 찍는다
                $msg = preg_match('/<script>alert\((.*?)\);<\/script>/s', $run['output'], $m) ? json_decode($m[1]) : null;
                throw new BoardMoa_Error(400, 'upload_failed', is_string($msg) && $msg !== '' ? str_replace(array('\\r\\n', "\r\n"), "\n", $msg) : BoardMoa_Text::t('사진을 올리지 못했습니다.'), true);
            }
        }
        clearstatcache();
        return BoardMoa_Api::profile(get_member($mb['mb_id']));
    }

    /** 처리 파일은 크기(바이트)가 넘으면 받지 않는다: 회원이미지 크기(가운데를 잘라 채움, 처리 파일의 thumbnail 과 같게)로 줄여 둔다 */
    private static function shrink($file, $width, $height, $maxBytes)
    {
        if ($width <= 0 || $height <= 0 || !function_exists('imagecreatefromstring')) {
            return;
        }
        $info = @getimagesize($file);
        if (!$info || !in_array($info[2], array(IMAGETYPE_JPEG, IMAGETYPE_PNG), true)) {
            return;
        }
        if ($info[0] <= $width && $info[1] <= $height && filesize($file) <= $maxBytes) {
            return;
        }
        $src = @imagecreatefromstring((string)file_get_contents($file));
        if (!$src) {
            return;
        }
        $scale = max($width / $info[0], $height / $info[1]);
        $cw = (int)round($width / $scale);
        $ch = (int)round($height / $scale);
        $dst = imagecreatetruecolor($width, $height);
        imagecopyresampled($dst, $src, 0, 0, (int)(($info[0] - $cw) / 2), (int)(($info[1] - $ch) / 2), $width, $height, $cw, $ch);
        if ($info[2] === IMAGETYPE_PNG) {
            imagesavealpha($dst, true);
            imagepng($dst, $file);
        } else {
            imagejpeg($dst, $file, 90);
        }
        imagedestroy($src);
        imagedestroy($dst);
    }

    // ---- 내부

    /** 로그인한 회원. 최고관리자는 웹도 회원정보 수정 화면을 열지 않는다(관리자 화면에서) */
    private static function member()
    {
        $mb = BoardMoa_Api::member();
        if ($GLOBALS['is_admin'] === 'super') {
            $url = defined('G5_ADMIN_URL') ? G5_ADMIN_URL . '/member_form.php?w=u&mb_id=' . urlencode($mb['mb_id']) : G5_URL;
            throw new BoardMoa_Error(403, 'not_permitted', BoardMoa_Text::t('관리자의 회원정보는 관리자 화면에서 수정해 주십시오.') . "\n" . $url, true);
        }
        return $mb;
    }

    /** 지금 비밀번호 확인 (웹 register_form.php 와 같은 check_password, common.php 의 이스케이프를 거친 값). 10분에 10번 틀리면 잠시 막는다 */
    private static function checkPassword($mb, $password)
    {
        $kind = 'me|' . $mb['mb_id'];
        BoardMoa_Write::limit($kind, 10, '비밀번호를 여러 번 틀렸습니다. 잠시 뒤에 다시 해 주세요.');
        if ($password === '' || !check_password(BoardMoa_Engine::escape($password), $mb['mb_password'])) {
            BoardMoa_Write::hit($kind);
            throw new BoardMoa_Error(400, 'invalid_password', '비밀번호가 맞지 않습니다.');
        }
    }

    /** 처리 파일에 넣을 지금 값 전부 (웹 양식이 보내는 이름으로) */
    private static function current($mb)
    {
        $values = array(
            'w' => 'u',
            'mb_id' => $mb['mb_id'],
            'mb_name' => $mb['mb_name'],
            'mb_nick' => $mb['mb_nick'],
            'mb_nick_default' => $mb['mb_nick'],
            'mb_email' => $mb['mb_email'],
            'old_email' => $mb['mb_email'],
            'mb_homepage' => $mb['mb_homepage'],
            'mb_tel' => $mb['mb_tel'],
            'mb_hp' => $mb['mb_hp'],
            'mb_zip' => $mb['mb_zip1'] . $mb['mb_zip2'],
            'mb_addr1' => $mb['mb_addr1'],
            'mb_addr2' => $mb['mb_addr2'],
            'mb_addr3' => $mb['mb_addr3'],
            'mb_addr_jibeon' => $mb['mb_addr_jibeon'],
            'mb_signature' => $mb['mb_signature'],
            'mb_profile' => $mb['mb_profile'],
            'mb_open' => $mb['mb_open'] ? '1' : '0',
            'mb_sex' => $mb['mb_sex'],
            'cert_type' => $mb['mb_certify'],
        );
        for ($i = 1; $i <= 10; $i++) {
            $values['mb_' . $i] = isset($mb['mb_' . $i]) ? $mb['mb_' . $i] : '';
        }
        // 정보공개를 바꿀 수 있을 때만 웹 양식처럼 mb_open_default (바뀌면 처리 파일이 정보공개 날짜를 새로)
        if (self::canChangeOpen($mb)) {
            $values['mb_open_default'] = $mb['mb_open'] ? '1' : '0';
        }
        // 수신 동의(mb_*_default)는 보내지 않는다: 처리 파일이 지금 값을 그대로 둔다
        return $values;
    }

    /**
     * 처리 파일 실행. 거절(alert)은 400 update_failed + 엔진 문구.
     * 웹 수정 양식처럼 자동등록방지(chk_captcha)를 엔진이 확인한다: 앱이 풀 수 있는 위젯(숫자 그림·reCAPTCHA v2)이면 captcha_response 를 받아 넘기고,
     * 없으면 403 captcha_required + 위젯. 위젯을 줄 수 없는 경우(보이지 않는 reCAPTCHA 등)만 엔진 필터(register_member_chk_captcha)로 건너뛴다:
     * 앱 요청은 토큰으로 로그인한 회원이 지금 비밀번호까지 확인했다(시도 제한과 함께).
     */
    private static function save($mb, array $values)
    {
        static $filtered = false;
        $widget = BoardMoa_Write::captchaWidget();
        if ($widget) {
            if (!BoardMoa_Write::captchaPass((string)BoardMoa_Api::param('captcha_response', ''), $widget)) {
                throw new BoardMoa_Error(403, 'captcha_required', '자동등록방지 확인이 필요합니다.', false, array('captcha' => $widget));
            }
        } elseif (!$filtered && function_exists('add_replace')) {
            $filtered = true;
            add_replace('register_member_chk_captcha', function ($fail = false, $w = '') {
                return BoardMoa_Me::$savingFlag ? false : $fail;
            }, 99, 2);
        }
        // register_form.php 가 수정 화면을 열 때 세션에 넣는 값: 이름·휴대폰이 그대로면 본인확인을 지우지 않는다, 본인확인 진행 값은 비운다
        set_session('ss_reg_mb_name', $mb['mb_name']);
        set_session('ss_reg_mb_hp', $mb['mb_hp']);
        set_session('ss_cert_no', '');
        set_session('ss_cert_hash', '');
        set_session('ss_cert_type', '');
        BoardMoa_Engine::input($values);
        self::$savingFlag = true;
        try {
            $run = BoardMoa_Engine::run(G5_BBS_PATH . '/register_form_update.php');
        } catch (BoardMoa_Alert $e) {
            if ($widget && strpos($e->getMessage(), '자동등록방지') !== false) {
                throw new BoardMoa_Error(403, 'captcha_required', $e->getMessage(), true, array('captcha' => BoardMoa_Write::captchaWidget()));
            }
            throw new BoardMoa_Error(400, 'update_failed', $e->getMessage(), true);
        } finally {
            self::$savingFlag = false;
        }
        return $run;
    }

    /** 이번 요청에서 처리 파일을 실행하는 중 (캡챠 필터가 본다) */
    public static $savingFlag = false;
}
